import styled from "styled-components";

export const space = styled.div`
  height: ${(props: any) => props.size + "px"};
`;
