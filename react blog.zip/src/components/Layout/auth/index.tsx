import * as S from './styles';

const AuthLayout = ({ children }: any) => {
  return <S.Container className="sssss">{children}</S.Container>;
};

export default AuthLayout;
