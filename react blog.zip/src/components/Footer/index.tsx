const Footer = () => {
  return <footer className="py-8 text-center">Copyright © 2023. Reza Shoja</footer>;
};

export default Footer;
