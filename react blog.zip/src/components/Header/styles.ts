import { styled } from 'styled-components';

export const Nav = styled.nav``;
export const Ul = styled.ul`
    display: flex;
    align-items: center;
    gap: 20px;
`;
export const Li = styled.li``;
